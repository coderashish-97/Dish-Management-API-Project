from rest_framework import serializers
from .models import dish_table,category

class categorySerializer(serializers.ModelSerializer):
    class Meta:
        model = category
        fields = ['id' ,'categoryname' ]
        read_only_fields = ['id']

class dish_tableSerializer(serializers.ModelSerializer):
    class Meta:
        model = dish_table
        fields = ['id' ,'dishname' , 'price' , 'categoryname' , 'image']
        read_only_fields = ['id']

