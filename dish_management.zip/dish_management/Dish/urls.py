from django.urls import path,include
from rest_framework.routers import DefaultRouter
from .views import dish_tableViewSet,categoryViewSet



# Create routers for dishes and categories

category_router = DefaultRouter()
category_router.register(r'category', categoryViewSet, basename='category')

dish_router = DefaultRouter()
dish_router.register(r'dish', dish_tableViewSet, basename='dish')



app_name = 'DISH_MANAGEMENT'

urlpatterns = [
    path('', include(dish_router.urls)),      # Include dish URLs
    path('', include(category_router.urls)),  # Include category URLs
]
